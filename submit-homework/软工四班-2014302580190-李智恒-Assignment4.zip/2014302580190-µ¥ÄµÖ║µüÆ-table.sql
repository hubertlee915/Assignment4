CREATE TABLE `2014302580190_professor_info` (
  `name` varchar(45) NOT NULL,
  `phone_number` varchar(1000) NOT NULL,
  `research_interests` varchar(1000) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8